# Load X and y variable
using JLD
data = load("markovData.jld")
(p0,pT_long,pT_short1,pT_short2) = (data["p0"],data["pT_long"],data["pT_short1"],data["pT_short2"])

include("exactDecode.jl")
decode_short1 = exactDecode(p0,pT_short1)
decode_short2 = exactDecode(p0,pT_short2)

@show(decode_short1)
@show(decode_short2)
